#include <iostream>

struct polynomial {
    float coef ;
    int exp ;
}

inputPoly(polynomial , int) ;
displayPoly(polynomial , int) ;
addPoly(polynomial[] ,polynomial[] , polynomial[] , int , int , int ) ;

int main(){
    int S1 , S2 , S3 ;
    polynomial P1[20] , P2[20] , P3[20] ;
    
    inputPoly( P1 , S1 ) ;
    inputPoly( P2 , S2 ) ;

    displayPoly(P1 , S1) ;
    displayPoly(P2 , S2) ;

    addPoly(P1 , P2 , P3 , S1 ,S2 , S3) ;

    displayPoly(P3 , S3) ;

}
void inputPoly(polynomial P , int S){
    
    cout << "Enter the Terms in Polynomial (in Decreasing Exponents )" << endl ;
    cin >> S ;
    for( int i = 0 , i < S ; i++ ){
        cout << "Enter the " << i+1 << " term" << endl ;
        cout << "Coeffecint : " ; cin >> P[0].coef ;
        cout << "Exponet : " ; cin >> P[0].exp ;
    }


}
